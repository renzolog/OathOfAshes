# Oath of Ashes — Android build

The whole game is `www/index.html` (self-contained: code, procedural art, audio and fonts are inlined, so it runs offline).
This folder wraps it in a Capacitor 6 shell.

## Build in CI
Push this folder to a GitHub repo: `.github/workflows/build-apk.yml` builds `app-debug.apk` and attaches it as a workflow artifact.
`azure-pipelines.yml` does the same on Azure DevOps (Microsoft-hosted ubuntu-latest already has the Android SDK).

## Build locally
Requirements: Node 18+, JDK 17, Android SDK (API 34) with `ANDROID_HOME` set.

    npm install
    npx cap add android
    ./patch-android.sh        # landscape lock + immersive fullscreen
    npx cap sync android
    cd android && ./gradlew assembleDebug

APK: `android/app/build/outputs/apk/debug/app-debug.apk` — install with `adb install -r app-debug.apk`
or copy it to the phone and allow installs from unknown sources.

For a release build: `./gradlew assembleRelease` and sign it with your keystore (`apksigner`).

## Controls
Tap the view: strike if a foe is in front, otherwise use (doors, levers, people, suspicious walls).
Swipe left/right to turn, up/down to step. The stone pad does the same, plus strafing.
Keyboard: WASD/arrows, Q/E turn, Space strike, Enter use, Z wait, M map, H drink, 1–5 rites.

The game autosaves at the start of each level; "Rise again" after death reloads it.
