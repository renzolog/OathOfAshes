#!/usr/bin/env bash
# Run after `npx cap add android`: lock to landscape and hide the system bars.
set -e
M=android/app/src/main/AndroidManifest.xml
grep -q screenOrientation "$M" || sed -i 's/<activity/<activity android:screenOrientation="sensorLandscape"/' "$M"
A=$(find android/app/src/main/java -name MainActivity.java | head -1)
if ! grep -q onWindowFocusChanged "$A"; then
cat > "$A" <<JAVA
package com.oathofashes.game;

import android.view.View;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) {
      getWindow().getDecorView().setSystemUiVisibility(
        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }
  }
}
JAVA
fi

# App icon: generate every Android density + adaptive layers from assets/
if [ -f assets/icon-only.png ]; then
  npx capacitor-assets generate --android --iconBackgroundColor '#020406' --iconBackgroundColorDark '#020406' \
    || echo "::warning::Icon generation failed, the default Capacitor icon will be used"
fi
